package com.cg.app.Service;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.app.Entities.AccountMaster;
import com.cg.app.Entities.Customer;
import com.cg.app.Entities.FundTransfer;
import com.cg.app.Entities.Payee;
import com.cg.app.Entities.Transactions;
import com.cg.app.Repository.AccountMasterRepository;
import com.cg.app.Repository.CustomerRepository;
import com.cg.app.Repository.FundTransferRepository;
import com.cg.app.Repository.PayeeRepository;
import com.cg.app.Repository.TransactionRepository;

@Service
public class FundTransferService {

	@Autowired
	private FundTransferRepository fundTransferRepository;

	@Autowired
	private TransactionRepository transactionRepository;

	@Autowired
	private PayeeRepository payeeRepository;

	@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	AccountMasterRepository accountMasterRepository;

	public boolean validatePayeeId(int payeeId) {
		Payee payee = payeeRepository.findOne(payeeId);
		if (payee != null)
			return true;
		else
			return false;
	}

	public Transactions addfundtransfer(int payeeId, FundTransfer fundtransfer) {

		Transactions transactions = new Transactions();
		Payee payee = payeeRepository.findOne(payeeId);
		Customer customer = customerRepository.findOne(payee.getAccountId());
		if (payee != null) {

			FundTransfer fundtransferRepo = fundTransferRepository.save(fundtransfer);

			transactions.setAccountId(fundtransfer.getCustId());
			transactions.setDateOfTransaction(fundtransfer.getDateofTransfer());
			transactions.setTranAmount(fundtransfer.getTransferAmount());
			transactions.setTrandescription("");
			transactions.setTransactionType("");

			transactionRepository.save(transactions);

			Double balance = payee.getAccountmaster().getAccountBalance();
			payee.getAccountmaster().setAccountBalance(balance + fundtransfer.getTransferAmount());
			payeeRepository.save(payee);
		}
//			
//			account accountDetails = 
//			payeeRepository.save(payee);
//			return transactions;
//		}
		else {
			return null;
		}

	}
}
