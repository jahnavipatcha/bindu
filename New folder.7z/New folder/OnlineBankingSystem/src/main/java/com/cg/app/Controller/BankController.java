package com.cg.app.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.app.Entities.AccountMaster;
import com.cg.app.Entities.Customer;
import com.cg.app.Entities.FundTransfer;
import com.cg.app.Entities.Payee;
import com.cg.app.Entities.Transactions;
import com.cg.app.Service.AccountMasterService;
import com.cg.app.Service.CustomerService;
import com.cg.app.Service.FundTransferService;
import com.cg.app.Service.PayeeService;
import com.cg.app.Service.TransactionService;

@RestController
public class BankController {

	@Autowired
	private CustomerService cservice;

	/************************ Create a new Account upon request *****************/

	/********************** Customer **********************************/

	/************ GET Method *************/

	@RequestMapping("/customer")
	public List<Customer> getAllCustomers() {
		return cservice.getAllCustomers();
	}

	/*************** POST method *************/

	@RequestMapping(value = "/customer", method = RequestMethod.POST)
	public Customer addCustomer(@RequestBody Customer cust) {
		return cservice.addCustomer(cust);

	}

	// *************************************AccountMaster**************************************************///

	@Autowired
	private AccountMasterService aservice;

	/*************** POST method *************/

	@RequestMapping(value = "/account", method = RequestMethod.POST)
	public AccountMaster addacc(@RequestBody AccountMaster accmaster) {
		return aservice.addacc(accmaster);

	}

	/************ GET Method *************/

	@RequestMapping("/accountmaster")
	public List<AccountMaster> getAllAccounts() {
		return aservice.getAllAccounts();
	}

	@RequestMapping(value = "/accountmaster/{accountId}", method = RequestMethod.GET)
	public AccountMaster getaccountdetails(@PathVariable int accountId) {
		return aservice.getaccountdetails(accountId);
	}

	/************ PUT Method *************/

	 @RequestMapping(value = "/account", method = RequestMethod.PUT) 
	 public Customer updateCustomer(@RequestBody Customer customer) 
	 { 
		 return cservice.updateCustomer(customer);
	 }
	 
	
/**************************************************payee*******************************************************/
	 
	 @Autowired
	 private PayeeService pservice;
	 
	 @RequestMapping(value="/addPayee",method=RequestMethod.POST)
	 public Payee addpayee(@RequestBody Payee payee) {
		return pservice.addpayee(payee);
		 
	 }

	 
	 @RequestMapping("/payee")
		public List<Payee> getAllPayees() {
			return pservice.getAllPayees();
		}
	 /*********************************************************************************************************/
	 
	 @Autowired
	 private FundTransferService tservice;
	 
	 
	 @RequestMapping(value="/payee/{payeeId}/Transfer",method=RequestMethod.POST)
	 public Transactions addfundtransfer(@PathVariable int payeeId,@RequestBody FundTransfer fundtransfer)
	 {
		return tservice.addfundtransfer(payeeId, fundtransfer);
		 
	 }

	//*************************************Transaction Calls**************************************************///
//	 @Autowired
//	 private TransactionService transactionService;
//
//	 @RequestMapping(value= "/customer/{accNo}/transfer" ,method=RequestMethod.POST)
//	 public Transactions addTransaction (@RequestBody Transactions transactions, @PathVariable int accountId) throws Exception
//	 {
//	 	return  transactionService.newTransacton(transactions, accountId);  
//	 }

	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
}
