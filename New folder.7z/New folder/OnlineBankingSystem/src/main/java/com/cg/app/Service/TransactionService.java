package com.cg.app.Service;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.app.Entities.AccountMaster;
import com.cg.app.Entities.Customer;
import com.cg.app.Entities.Payee;
import com.cg.app.Entities.Transactions;
import com.cg.app.Repository.AccountMasterRepository;
import com.cg.app.Repository.CustomerRepository;
import com.cg.app.Repository.PayeeRepository;
import com.cg.app.Repository.TransactionRepository;

@Service
public class TransactionService {
	@Autowired
	private TransactionRepository transactionRepository;

	@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	private PayeeRepository prepo;
	
	
	
	
}