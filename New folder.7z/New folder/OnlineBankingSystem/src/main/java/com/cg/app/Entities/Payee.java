package com.cg.app.Entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class Payee {

	@Id
	@SequenceGenerator(name = "seq", sequenceName = "seq", initialValue = 100000, allocationSize = 500)
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int payeeId;
	private int accountId; // payee accountId
	private String nickname;
	private String ifscCode;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "accountId", insertable = false, updatable = false)
	private AccountMaster accountmaster;

	/*
	 * @ManyToOne(cascade=CascadeType.ALL)
	 * 
	 * @JoinColumn(name = "custId") private Customer customer;
	 */

	@OneToMany(mappedBy = "payee")
	private List<FundTransfer> fundtransfer;

	public int getPayeeId() {
		return payeeId;
	}

	public void setPayeeId(int payeeId) {
		this.payeeId = payeeId;
	}

	/*
	 * public Customer getCustId() { return custId; }
	 * 
	 * public void setCustId(Customer custId) { this.custId = custId; }
	 */

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public AccountMaster getAccountmaster() {
		return accountmaster;
	}

	public void setAccountmaster(AccountMaster accountmaster) {
		this.accountmaster = accountmaster;
	}

}
