package com.cg.app.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.app.Entities.Transactions;

public interface TransactionRepository extends JpaRepository<Transactions,Integer> {

}
