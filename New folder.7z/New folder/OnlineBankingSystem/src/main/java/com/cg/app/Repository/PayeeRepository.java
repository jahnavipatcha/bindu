package com.cg.app.Repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.cg.app.Entities.Payee;

public interface PayeeRepository extends JpaRepository<Payee,Integer> {

}
