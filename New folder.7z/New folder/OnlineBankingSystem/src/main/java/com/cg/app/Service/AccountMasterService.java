package com.cg.app.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.app.Entities.AccountMaster;
import com.cg.app.Repository.AccountMasterRepository;
import com.cg.app.Repository.CustomerRepository;

@Service
public class AccountMasterService {

	@Autowired
	private AccountMasterRepository arepos;
	@Autowired
	private CustomerRepository customerRepo;

	/*****************************POST Method****************************************************/
	public AccountMaster addacc(AccountMaster accmaster) {
		accmaster.setCustomer(customerRepo.findOne(accmaster.getCustId()));
		return arepos.save(accmaster);
	}

	/*************************GET Method**************************************/

	public List<AccountMaster> getAllAccounts() {

		return arepos.findAll();
	}

	public AccountMaster getaccountdetails(int accountId) {

		if (ValiadateAccId(accountId))
			return arepos.getOne(accountId);
		else
			return null;
	}

	private boolean ValiadateAccId(int accountId) {
		AccountMaster employee = arepos.findOne(accountId);
		if (employee != null)
			return true;
		else
			return false;
	}

}
