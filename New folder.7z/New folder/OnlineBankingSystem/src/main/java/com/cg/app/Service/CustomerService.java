package com.cg.app.Service;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.app.Entities.Customer;
import com.cg.app.Repository.CustomerRepository;

@Service
public class CustomerService {
	@Autowired
	private CustomerRepository crepos;

	/*************** post service *************/

	public Customer addCustomer(Customer cust) {
		return crepos.save(cust);
	}

	/*************** GET service *************/

	public List<Customer> getAllCustomers() {

		return crepos.findAll();
	}

	/**********put service******/
	public Customer updateCustomer(Customer customer) {
		
		return crepos.save(customer);
	}


}
